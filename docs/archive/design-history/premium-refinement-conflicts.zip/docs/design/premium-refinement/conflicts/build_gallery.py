"""Index original conflict browser PNGs; no image processing."""

import hashlib
import json
import struct
from pathlib import Path

root = Path(__file__).resolve().parent
captures = []
for path in sorted(root.glob("*.png")):
    raw = path.read_bytes()
    width, height = struct.unpack(">II", raw[16:24])
    captures.append(
        {
            "file": path.name,
            "width": width,
            "height": height,
            "sha256": hashlib.sha256(raw).hexdigest(),
        }
    )
(root / "captures.json").write_text(
    json.dumps(captures, indent=2) + "\n", encoding="utf-8"
)
html = """<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Cortex · compact conflicts</title>
<style>*{box-sizing:border-box}body{margin:0;background:#f7f6ef;color:#173d30;font:16px/1.5 system-ui,sans-serif}header{padding:24px;background:#173d30;color:#fffef9}h1{font:32px Georgia,serif;margin:0}main{padding:24px}label{display:grid;gap:8px;min-width:0;max-width:100%}select{width:100%;min-width:0;max-width:100%;font:inherit;min-height:44px;padding:8px;background:#fffef9;color:#173d30;border:1px solid #7b8b7c}nav{display:flex;gap:24px;flex-wrap:wrap;margin-bottom:24px}.pair{display:grid;grid-template-columns:1fr 1fr;gap:24px;align-items:start}figure{margin:0;min-width:0}img{display:block;width:100%;height:auto;border:1px solid #d4dacf}.mobile img{max-width:390px;margin:auto}figcaption{margin-bottom:12px}a{color:inherit}section{margin-bottom:32px}@media(max-width:600px){.pair{grid-template-columns:1fr}header,main{padding:16px}}</style>
<header><h1>Cortex · compact conflicts</h1><p>Actual browser captures. Every historical occurrence remains inspectable. Previous document UI and original small documents restored; PR #8 stays draft.</p></header><main><nav><label>Viewport<select id="width"><option value="all">1440, 390 and 320</option><option>1440</option><option>390</option><option>320</option><option>1280</option><option>768</option></select></label><label>Theme<select id="theme"><option value="both">Both themes</option><option>light</option><option>dark</option></select></label></nav><div id="pairs"></div><p>Same five original events and two policies. No retouched images; clicks open original pixels. <a href="README.md">Tests and release status</a> · <a href="captures.json">Dimensions and SHA-256</a></p></main>
<script>const width=document.getElementById('width'),theme=document.getElementById('theme');function update(){const widths=width.value==='all'?[1440,390,320]:[Number(width.value)],themes=theme.value==='both'?['light','dark']:[theme.value],container=document.getElementById('pairs');container.replaceChildren();for(const t of themes)for(const w of widths){const section=document.createElement('section'),heading=document.createElement('h2'),pair=document.createElement('div');heading.textContent=w+'px · '+t;pair.className='pair'+(w<1100?' mobile':'');section.append(heading);for(const phase of ['before','after']){const file=t+'-conflicts-'+w+'.png',path=phase==='before'?'../rollout/after/'+file:file,figure=document.createElement('figure'),caption=document.createElement('figcaption'),link=document.createElement('a'),img=document.createElement('img');caption.textContent=phase==='before'?'Before · approved workspace rollout':'After · compact authorized groups';link.href=path;link.target='_blank';link.rel='noopener';img.src=path;img.alt=caption.textContent+' · '+w+'px · '+t;img.loading='lazy';link.append(img);figure.append(caption,link);pair.append(figure);}section.append(pair);container.append(section);}}for(const control of [width,theme])control.addEventListener('change',update);update();</script></html>"""
(root / "gallery.html").write_text(html, encoding="utf-8")
print(f"Indexed {len(captures)} untouched conflict captures.")
