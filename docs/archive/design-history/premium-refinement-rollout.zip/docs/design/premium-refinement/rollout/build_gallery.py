"""Index unmodified browser captures; no image processing."""
import hashlib
import json
import struct
from pathlib import Path

root = Path(__file__).resolve().parent
pairs = []
for before in sorted((root / "before").glob("*.png")):
    after = root / "after" / before.name
    theme, page, width = before.stem.split("-")
    pair = {"theme": theme, "page": page, "viewport": int(width)}
    for phase, path in [("before", before), ("after", after)]:
        raw = path.read_bytes()
        w, h = struct.unpack(">II", raw[16:24])
        pair[phase] = {"path": f"{phase}/{path.name}", "width": w, "height": h,
                       "sha256": hashlib.sha256(raw).hexdigest()}
    pairs.append(pair)
(root / "captures.json").write_text(json.dumps(pairs, indent=2) + "\n", encoding="utf-8")
pages = {"library": "Document Library", "document": "Document Details", "conflicts": "Conflicts", "activity": "Activity", "permissions": "Permissions", "grants": "Document grants", "audit": "Audit", "upload": "Upload", "dashboard": "Dashboard", "login": "Login"}
html = '''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Cortex · approved direction rollout</title>
<style>*{box-sizing:border-box}body{margin:0;background:#f7f6ef;color:#173d30;font:16px/1.5 system-ui,sans-serif}header{padding:24px 32px;background:#173d30;color:#fffef9}h1{margin:0;font:32px Georgia,serif}header p{margin:8px 0 0;max-width:100ch}a{color:inherit}main{padding:24px 32px}.controls{display:flex;gap:20px;flex-wrap:wrap;margin-bottom:24px}label{display:grid;gap:6px}select{font:inherit;padding:10px;background:#fffef9;color:#173d30;border:1px solid #7b8b7c;border-radius:6px;min-height:44px}select:focus-visible,a:focus-visible{outline:3px solid #173d30;outline-offset:4px}.pair{display:grid;grid-template-columns:1fr 1fr;gap:24px;align-items:start}figure{margin:0;min-width:0}figcaption{margin:0 0 12px}img{display:block;width:100%;height:auto;border:1px solid #d4dacf}.mobile img{max-width:390px;margin:auto}section{margin-bottom:40px}h2{font:24px Georgia,serif}.notice{max-width:100ch;color:#58675d}@media(max-width:600px){header,main{padding:20px 16px}.pair{grid-template-columns:1fr}}</style>
<header><h1>Cortex · full workspace rollout</h1><p>Actual local Chromium screenshots. Approved Ask direction extended to every remaining route. PR #8 stays draft; production has not been deployed or merged.</p></header><main><div class="controls">
<label>Page<select id="page">OPTIONS</select></label><label>Viewport<select id="width"><option value="all">All required widths</option><option>1440</option><option>390</option><option>320</option><option>1280</option><option>768</option></select></label><label>Theme<select id="theme"><option value="both">Both themes</option><option>light</option><option>dark</option></select></label></div>
<p id="status" role="status"></p><div id="pairs"></div><p class="notice">200 unmodified captures / 100 pairs. Same fictional profiles and documents; history and audit event counts can change as local verification creates events. Audit reflects the API's latest 100 events; Activity reflects up to 30 permitted requests. Capture focus is cleared. Click each screenshot for the original pixels.</p><p><a href="README.md">Design choices and verification</a> · <a href="captures.json">Dimensions and SHA-256 manifest</a> · <a href="http://127.0.0.1:5173/documents">Open local application</a></p></main>
<script>const page=document.getElementById('page'),width=document.getElementById('width'),theme=document.getElementById('theme');function update(){const widths=width.value==='all'?[1440,390,320]:[Number(width.value)],themes=theme.value==='both'?['light','dark']:[theme.value],container=document.getElementById('pairs');container.replaceChildren();for(const t of themes)for(const w of widths){const section=document.createElement('section'),heading=document.createElement('h2'),pair=document.createElement('div');heading.textContent=page.options[page.selectedIndex].text+' · '+w+'px · '+t;section.append(heading);pair.className='pair'+(w<1100?' mobile':'');for(const phase of ['before','after']){const path=phase+'/'+t+'-'+page.value+'-'+w+'.png',figure=document.createElement('figure'),caption=document.createElement('figcaption'),link=document.createElement('a'),img=document.createElement('img');caption.textContent=phase==='before'?'Before · approved Ask baseline':'After · complete rollout for review';link.href=path;link.target='_blank';link.rel='noopener';img.src=path;img.loading='lazy';img.alt=phase+' '+t+' '+page.value+' at '+w+' pixels';link.append(img);figure.append(caption,link);pair.append(figure);}section.append(pair);container.append(section);}document.getElementById('status').textContent=(widths.length*themes.length)+' actual before/after pairs shown.';}for(const control of [page,width,theme])control.addEventListener('change',update);update();</script></html>'''
html = html.replace("OPTIONS", "".join(f'<option value="{key}">{label}</option>' for key, label in pages.items()))
(root / "gallery.html").write_text(html, encoding="utf-8")
review = ["# Actual browser comparisons", "", "Required 1440/390/320px, both themes. Extra 768/1280 captures are indexed in the gallery. Same real fictional profiles and documents; audit/history are evolving local records. No images have been retouched.", ""]
for page, label in pages.items():
    for theme in ["light", "dark"]:
        for width in [1440, 390, 320]:
            name = f"{theme}-{page}-{width}.png"
            review.extend([f"## {label} · {theme} · {width}px", "", "| Before | After |", "|---|---|", f"| ![Before](before/{name}) | ![After](after/{name}) |", ""])
(root / "SCREENSHOTS.md").write_text("\n".join(review), encoding="utf-8")
print(f"Indexed {len(pairs)} actual before/after pairs.")
